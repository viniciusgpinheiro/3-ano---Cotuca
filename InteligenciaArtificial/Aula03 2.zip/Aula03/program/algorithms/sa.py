from program.core.algorithm import Algorithm
from program.core.solution import Solution
import random


class SimulatedAnnealing(Algorithm):
    def __init__(self, termination, problem, verbose=False):
        super().__init__(termination, problem, verbose)

    
    def initialize(self):
        self.initial_solution = self.__get_initial_solution()
        self.current_solution = self.initial_solution.copy()
        self.initial_temperature = 100


    def advance(self):
        pass


    def finalize(self):
        pass


    def __get_initial_solution(self): # Retorna uma solução aleatória
        initial_solution = Solution(
            value = random.sample(list(range(self.problem.size)), self.problem.size) 
        )
        initial_solution.cost = self.problem.evaluate(initial_solution.value) 
        return initial_solution
    

    def __get_neighbours(self, current_solution):
        i, j = random.sample(list(range(self.problem.size)), 2)
        neighbour_solution = current_solution.copy()
        neighbour_solution.value[i], neighbour_solution[j] = neighbour_solution[j], neighbour_solution[i]
        neighbour_solution.cost = self.problem.evaluate(neighbour_solution.value)
        return neighbour_solution